
# 无加密
cctvurl = 'http://hls.cntv.kcdnvip.com/asp/hls/850/0303000a/3/default/25eb64a95f094a42bbdea5b23ae756f9/850.m3u8'
# AES
polyv = 'https://hls.videocc.net/4adf37ccc0/a/4adf37ccc0342e919fef2de4d02b473a_3.m3u8'
polyv_key = 'kQ2aSmyG1FDSmzpqTso/0w=='
master = 'https://hls.videocc.net/4adf37ccc0/a/4adf37ccc0342e919fef2de4d02b473a.m3u8'
xet = 'https://1252524126.vod2.myqcloud.com/529d8d60vodtransbj1252524126/cbcde1e4387702298833985463/drm/v.f421220.m3u8'

# headers_range #EXT-X-BYTERANGE:631868@0
headers_range = 'https://y.qq.com/n/ryqq/mv/q0043ytfvmn'
# SAMPLE-AES-CTR https://v.qq.com/x/cover/mzc00200q06w7zx/l0033spqumo.html?n_version=2021

