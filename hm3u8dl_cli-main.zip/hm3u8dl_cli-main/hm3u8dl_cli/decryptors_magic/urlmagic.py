
def decrypt(m3u8url:str):
    return m3u8url.replace('&amp;','&')