# Video_Audio_Record
When You Can just Watch the Video but You Can't Download!

当你只能看不能摸的时候！自动录屏吧！

Automatically record Screen(video and audio) on the computer, and combine them into mp4 file with ffmpeg 

自动录制音频、视频，并合并转换为mp4格式

遵纪守法，谨慎使用！

示例DEMO

![](output.mp4_20191211_181627.gif?raw=true)
